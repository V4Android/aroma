<@center><b><#selectbg_g>Terms of Use</#></b>

The Authors of this Aroma are not responsible for any possible damage done to your device as a result of flashing this ROM.

If you are not willing to agree with these conditions,
please do not continue the installation process.